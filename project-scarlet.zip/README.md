# Project Starlight / SCARLET

Une première version jouable de ta vie en aventure. Interface française, assets SVG originaux, ville nocturne, panneaux découpés, cartes en perspective CSS, transitions Framer Motion. Aucun asset, personnage, son ou police propriétaire de Persona n’est inclus. Les polices Barlow et Barlow Condensed sont libres (SIL OFL), distribuées par Fontsource et hébergées avec l’application. Aucun appel à Google Fonts.

## Démarrer dans un dépôt GitHub Codespaces vide

### Importer l’archive dans `sansidentitee/starlight`

Ouvrir le dépôt dans Codespaces (bouton **Code → Codespaces → Create codespace on main**), puis glisser `project-scarlet.zip` dans l’explorateur de fichiers du Codespace. Dans son terminal, à la racine du dépôt vide :

```bash
unzip project-scarlet.zip
npm ci
npm run dev
```

L’archive contient les fichiers directement à la racine, avec `.devcontainer` et `.env.example`, sans `.git`, cache ni dépendances installées. Le premier démarrage fonctionne sans Supabase. Ouvrir le port 3000 ; créer son nom de code dans le tutoriel. Avant le premier commit, retirer l’archive du dépôt ou ajouter son nom à `.gitignore`.

### Installation standard

Copier **le contenu de ce dossier** à la racine du dépôt, y compris les fichiers cachés. Ne pas copier node_modules ou .next. Ouvrir le dépôt dans Codespaces. La configuration `.devcontainer` installe Node 22 et exécute `npm ci`.

```bash
npm ci
cp .env.example .env.local
npm run dev
```

Ouvrir le port 3000 depuis l’onglet Ports. Sans variables Supabase, l’application fonctionne en mode local avec localStorage. Le premier accès présente un tutoriel en cinq étapes. Après la création du profil, le repaire devient accessible. Node 22 minimum (requis par la version de Supabase installée).

## Parcours disponibles

- `/` : repaire, scène urbaine, date réelle, niveau, quêtes, Palais, calendrier, Mementos, stats, Confidants, Journal, Chambre.
- `/onboarding` : tutoriel Objectif → Quêtes → Stats → Palais/Mementos → profil.
- `/quetes` : ajouter une quête, choisir une date/stat/Palais, terminer, filtrer.
- `/palais` : créer un projet et ses étapes, progression, quêtes associées.
- `/mementos` : carte interactive des petites tâches, création et résolution.
- `/calendrier` : navigation mensuelle et quêtes par jour.
- `/confidants` : créer un lien, enregistrer un moment partagé, rangs 1–10.
- `/stats`, `/journal`, `/compendium` : radar, progression, écriture et réussites.
- `/chambre` : respiration et thème ; `/parametres` : accessibilité, export, synchronisation.
- `/profil`, `/connexion` : profil, inscription et connexion réelles via Supabase.

La partie initiale contient des exemples éditoriaux de quêtes et un Palais, mais aucune progression ni personne fictive. Une quête rapporte 30 XP (les exemples affichent leur propre récompense), une requête 15, une étape de Palais 75. Un niveau tous les 250 XP. Accomplir une quête ne peut rapporter deux fois. Les étapes de Palais sont validées explicitement ; les quêtes associées ne les terminent pas automatiquement. Un moment partagé par Confidant et par jour, +20 XP et Empathie, rang maximal 10. Aucun message envoyé aux contacts. Aucune musique ni faux lecteur.

## Supabase

1. Créer un projet Supabase et exécuter `supabase/migrations/001_player_saves.sql` dans SQL Editor.
2. Dans Authentication, activer le fournisseur Email et la confirmation d’e-mail. Configurer SMTP pour une utilisation publique (les limites du service d’envoi de test ne conviennent pas à un lancement).
3. Dans Authentication → URL Configuration, définir Site URL sur l’URL de production. Ajouter `https://votre-domaine/connexion`, `http://localhost:3000/connexion` et l’URL exacte du port Codespaces suivie de `/connexion` aux Redirect URLs. Prévoir les domaines de preview utilisés, sans autoriser arbitrairement tous les domaines.
4. Compléter `.env.local` :

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://votre-projet.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=votre-cle-publishable-ou-anon
```

Ne jamais utiliser de clé service_role ou secret côté navigateur. Redémarrer le serveur après un changement d’environnement. L’inscription peut demander une confirmation par e-mail ; la connexion utilise `signInWithPassword`.

La table `player_saves` stocke une aventure JSON versionnée par utilisateur. Les politiques RLS isolent lecture, écriture et suppression avec `auth.uid()`. Aucune liste publique des profils. Les changements sont sauvegardés en série ; le statut signale un échec, avec une copie locale de secours et un bouton de nouvelle synchronisation. Une sauvegarde illisible n’est pas écrasée. Chaque compte démarre sa propre aventure : la partie invitée reste séparée. Les sauvegardes cloud sont chargées à la connexion ; le mode invité est restauré à la déconnexion.

Cette version personnelle fonctionne en « dernière écriture gagnante » entre appareils, sans fusion collaborative. Éviter de modifier simultanément la même partie sur plusieurs appareils. Les copies locales privées restent dans le navigateur après déconnexion ; effacer les données du site sur une machine partagée. Le JSON peut être exporté, mais l’import et la récupération de mot de passe ne sont pas inclus dans cette première version.

## Déploiement Vercel

1. Pousser le dépôt sur GitHub, puis l’importer dans Vercel.
2. Preset Next.js, racine du dépôt, commande `npm run build`, sortie par défaut. Sélectionner Node 22.
3. Définir les deux variables publiques pour les environnements souhaités, puis déployer.
4. Reporter le domaine final dans Supabase (Site URL et Redirect URLs) ; redéployer après modification des variables.
5. Vérifier inscription, confirmation d’e-mail, connexion, création de quête, rechargement, déconnexion et isolation avec un second compte.

Le dépôt est prêt à déployer ; il ne crée pas automatiquement de projet Supabase/Vercel et n’inclut aucun identifiant. Pour ouvrir largement le service, compléter les pages légales et la politique de conservation, le flux de suppression de compte, la récupération de mot de passe, l’anti-abus/CAPTCHA et la surveillance selon les besoins du lancement. Les points sont un système de progression personnel, non une monnaie ou un classement compétitif : les récompenses sont calculées côté client.

## Architecture et vérifications

```text
src/app/                  Layout, styles, routes et contrôle des chemins
src/components/game.tsx   Écrans et actions utilisateur
src/components/art.tsx    Ville SVG et perspective interactive originales
src/components/game-provider.tsx  Session, isolation, sauvegarde locale/cloud
src/lib/game.ts           Modèle versionné, données initiales, règles de progression
src/lib/supabase.ts       Client Supabase, absent en mode local
supabase/migrations/      Table, politiques RLS et horodatage
tests/                    Invariants de progression et validation des sauvegardes
```

```bash
npm run typecheck
npm test
npm run build
npm start
```

La 3D CSS évite un canvas WebGL permanent : pas de téléchargement Three.js, pas de textures lourdes. Parallaxe limitée, SVG vectoriels, responsive, navigation clavier, labels de formulaire, focus visibles, préférence système de réduction du mouvement et réglage manuel. Tailwind 4 est disponible ; la direction artistique utilise surtout des classes CSS dédiées. Next.js App Router + TypeScript strict + React 19 + Framer Motion + Supabase JS.

Documentation : [Next.js](https://nextjs.org/docs/app/getting-started/installation), [Supabase Auth](https://supabase.com/docs/guides/auth), [RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [Vercel](https://vercel.com/docs/frameworks/full-stack/nextjs).
