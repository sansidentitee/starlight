-- Run once in the Supabase SQL editor. Only publishable/anon keys belong in the browser.
create table public.player_saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null check (jsonb_typeof(data) = 'object' and data ->> 'version' = '1'),
  updated_at timestamptz not null default now()
);
alter table public.player_saves enable row level security;
revoke all on public.player_saves from anon;
grant select, insert, update, delete on public.player_saves to authenticated;
create policy "Read own adventure" on public.player_saves for select to authenticated using ((select auth.uid()) = user_id);
create policy "Create own adventure" on public.player_saves for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Update own adventure" on public.player_saves for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Delete own adventure" on public.player_saves for delete to authenticated using ((select auth.uid()) = user_id);
create function public.touch_player_save() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger player_save_updated before update on public.player_saves for each row execute function public.touch_player_save();
