import { test } from "node:test";
import assert from "node:assert/strict";
import {
  initialState,
  completeQuest,
  completePalaceStep,
  recordContact,
  level,
  isGameState,
} from "../src/lib/game";
test("a quest awards XP and only its associated stat, exactly once", () => {
  const before = initialState();
  const after = completeQuest(before, "q1");
  assert.equal(after.xp, 30);
  assert.equal(after.stats.Connaissance, 30);
  assert.equal(after.stats.Courage, 0);
  assert.equal(before.xp, 0);
  assert.equal(completeQuest(after, "q1"), after);
});
test("unknown quest cannot grant XP", () => {
  const s = initialState();
  assert.equal(completeQuest(s, "unknown"), s);
});
test("a palace step cannot reward a duplicate click or exceed the final step", () => {
  const before = initialState();
  const first = completePalaceStep(before, "p1", 0);
  assert.equal(first.xp, 75);
  assert.equal(completePalaceStep(first, "p1", 0), first);
  let final = first;
  for (let i = 1; i < 5; i++) final = completePalaceStep(final, "p1", i);
  assert.equal(final.palaces[0].completed, 5);
  assert.equal(final.xp, 375);
  assert.equal(completePalaceStep(final, "p1", 5), final);
});
test("confidants reward once per day and stop at rank ten", () => {
  const before = initialState();
  before.confidants = [
    { id: "c1", name: "Test", role: "Ami", rank: 8, lastContact: "" },
  ];
  const after = recordContact(before, "c1", "2026-09-23");
  assert.equal(after.xp, 20);
  assert.equal(after.stats.Empathie, 20);
  assert.equal(after.confidants[0].rank, 9);
  assert.equal(recordContact(after, "c1", "2026-09-23"), after);
  const max = recordContact(after, "c1", "2026-09-24");
  assert.equal(recordContact(max, "c1", "2026-09-25"), max);
});
test("levels advance at 250 XP boundaries", () => {
  assert.equal(level(0), 1);
  assert.equal(level(249), 1);
  assert.equal(level(250), 2);
  assert.equal(level(1000), 5);
});
test("invalid saved state is rejected before hydration", () => {
  const s = initialState();
  assert.equal(isGameState(s), true);
  assert.equal(isGameState({ ...s, quests: [{ id: "x" }] }), false);
  assert.equal(isGameState({ ...s, stats: {} }), false);
  assert.equal(isGameState({ ...s, xp: -1 }), false);
  assert.equal(
    isGameState({ ...s, palaces: [{ ...s.palaces[0], completed: 50 }] }),
    false,
  );
});
