export const statNames = [
  "Connaissance",
  "Courage",
  "Expression",
  "Discipline",
  "Empathie",
] as const;
export type Stat = (typeof statNames)[number];
export type Quest = {
  id: string;
  title: string;
  stat: Stat;
  xp: number;
  done: boolean;
  date: string;
  palace?: string;
  kind: "quest" | "mementos";
};
export type Palace = {
  id: string;
  title: string;
  subtitle: string;
  steps: string[];
  completed: number;
};
export type GameState = {
  version: 1;
  name: string;
  objective: string;
  onboarded: boolean;
  xp: number;
  stats: Record<Stat, number>;
  quests: Quest[];
  palaces: Palace[];
  confidants: {
    id: string;
    name: string;
    role: string;
    rank: number;
    lastContact: string;
  }[];
  journal: { id: string; date: string; mood: string; text: string }[];
  lowMotion: boolean;
  accent: "scarlet" | "moon";
};
export function localDate(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function initialState(): GameState {
  const date = localDate();
  return {
    version: 1,
    name: "Voyageur",
    objective: "Faire le premier pas",
    onboarded: false,
    xp: 0,
    stats: {
      Connaissance: 0,
      Courage: 0,
      Expression: 0,
      Discipline: 0,
      Empathie: 0,
    },
    quests: [
      {
        id: "q1",
        title: "Lire 10 pages, ouvrir un nouveau monde",
        stat: "Connaissance",
        xp: 30,
        done: false,
        date,
        kind: "quest",
        palace: "p1",
      },
      {
        id: "q2",
        title: "20 minutes pour mon grand projet",
        stat: "Discipline",
        xp: 50,
        done: false,
        date,
        kind: "quest",
        palace: "p1",
      },
      {
        id: "q3",
        title: "Prendre des nouvelles de quelqu’un",
        stat: "Empathie",
        xp: 25,
        done: false,
        date,
        kind: "quest",
      },
      {
        id: "m1",
        title: "Libérer mon espace de travail",
        stat: "Discipline",
        xp: 15,
        done: false,
        date,
        kind: "mementos",
      },
      {
        id: "m2",
        title: "Répondre à ce message en attente",
        stat: "Courage",
        xp: 15,
        done: false,
        date,
        kind: "mementos",
      },
    ],
    palaces: [
      {
        id: "p1",
        title: "La Citadelle du Demain",
        subtitle: "Transformer une envie en réalité",
        steps: [
          "Définir mon objectif",
          "Explorer une première piste",
          "Créer une première version",
          "Partager mon travail",
          "Célébrer le chemin",
        ],
        completed: 0,
      },
    ],
    confidants: [],
    journal: [],
    lowMotion: false,
    accent: "scarlet",
  };
}
export function completeQuest(state: GameState, id: string): GameState {
  const q = state.quests.find((q) => q.id === id);
  if (!q || q.done) return state;
  return {
    ...state,
    xp: state.xp + q.xp,
    stats: { ...state.stats, [q.stat]: state.stats[q.stat] + q.xp },
    quests: state.quests.map((q) => (q.id === id ? { ...q, done: true } : q)),
  };
}
export const level = (xp: number) => Math.floor(xp / 250) + 1;
export function completePalaceStep(
  state: GameState,
  id: string,
  expectedStep: number,
): GameState {
  const palace = state.palaces.find((p) => p.id === id);
  if (
    !palace ||
    palace.completed !== expectedStep ||
    palace.completed >= palace.steps.length
  )
    return state;
  return {
    ...state,
    xp: state.xp + 75,
    palaces: state.palaces.map((p) =>
      p.id === id ? { ...p, completed: p.completed + 1 } : p,
    ),
  };
}
export function recordContact(
  state: GameState,
  id: string,
  date = localDate(),
): GameState {
  const contact = state.confidants.find((c) => c.id === id);
  if (!contact || contact.lastContact === date || contact.rank >= 10)
    return state;
  return {
    ...state,
    xp: state.xp + 20,
    stats: { ...state.stats, Empathie: state.stats.Empathie + 20 },
    confidants: state.confidants.map((c) =>
      c.id === id ? { ...c, rank: c.rank + 1, lastContact: date } : c,
    ),
  };
}
export function isGameState(value: unknown): value is GameState {
  if (!value || typeof value !== "object") return false;
  const s = value as GameState;
  return (
    s.version === 1 &&
    typeof s.name === "string" &&
    typeof s.objective === "string" &&
    typeof s.onboarded === "boolean" &&
    Number.isFinite(s.xp) &&
    s.xp >= 0 &&
    !!s.stats &&
    statNames.every((k) => Number.isFinite(s.stats[k]) && s.stats[k] >= 0) &&
    Array.isArray(s.quests) &&
    s.quests.every(
      (q) =>
        typeof q.id === "string" &&
        typeof q.title === "string" &&
        statNames.includes(q.stat) &&
        Number.isFinite(q.xp) &&
        q.xp > 0 &&
        typeof q.done === "boolean" &&
        typeof q.date === "string" &&
        ["quest", "mementos"].includes(q.kind),
    ) &&
    Array.isArray(s.palaces) &&
    s.palaces.every(
      (p) =>
        typeof p.id === "string" &&
        typeof p.title === "string" &&
        typeof p.subtitle === "string" &&
        Array.isArray(p.steps) &&
        p.steps.every((x) => typeof x === "string") &&
        Number.isInteger(p.completed) &&
        p.completed >= 0 &&
        p.completed <= p.steps.length,
    ) &&
    Array.isArray(s.confidants) &&
    s.confidants.every(
      (c) =>
        typeof c.id === "string" &&
        typeof c.name === "string" &&
        typeof c.role === "string" &&
        Number.isInteger(c.rank) &&
        c.rank >= 1 &&
        c.rank <= 10 &&
        typeof c.lastContact === "string",
    ) &&
    Array.isArray(s.journal) &&
    s.journal.every(
      (j) =>
        typeof j.id === "string" &&
        typeof j.date === "string" &&
        typeof j.mood === "string" &&
        typeof j.text === "string",
    ) &&
    typeof s.lowMotion === "boolean" &&
    ["scarlet", "moon"].includes(s.accent)
  );
}
