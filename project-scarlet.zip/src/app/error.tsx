"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main className="loading">
      <span className="eyebrow">SIGNAL INTERROMPU</span>
      <h1>LE PASSAGE EST INSTABLE.</h1>
      <p>
        Une erreur a interrompu l’affichage. Réessaie pour reprendre ton
        aventure.
      </p>
      <button className="button" onClick={reset}>
        RÉESSAYER ↗
      </button>
    </main>
  );
}
