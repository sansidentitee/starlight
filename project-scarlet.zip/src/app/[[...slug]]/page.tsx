import { Game } from "@/components/game";
import { notFound } from "next/navigation";
const routes = [
  "quetes",
  "calendrier",
  "confidants",
  "palais",
  "mementos",
  "stats",
  "journal",
  "compendium",
  "chambre",
  "parametres",
  "profil",
  "connexion",
  "onboarding",
];
export default async function Page({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { slug } = await params;
  if (slug && (slug.length !== 1 || !routes.includes(slug[0]))) notFound();
  return <Game page={slug?.[0] || "accueil"} />;
}
