import Link from "next/link";
export default function NotFound() {
  return (
    <main className="loading">
      <span className="eyebrow">SECTEUR 404</span>
      <h1>CE PASSAGE N’EXISTE PAS.</h1>
      <p>Reviens au repaire pour retrouver ton chemin.</p>
      <Link href="/" className="button">
        RETOUR AU REPAIRE ↗
      </Link>
    </main>
  );
}
