import type { Metadata } from "next";
import "@fontsource/barlow/400.css";
import "@fontsource/barlow/500.css";
import "@fontsource/barlow/600.css";
import "@fontsource/barlow-condensed/600.css";
import "@fontsource/barlow-condensed/800.css";
import "./globals.css";
import { GameProvider } from "@/components/game-provider";
export const metadata: Metadata = {
  title: "SCARLET — Réécris ton histoire",
  description: "Project Starlight. Tes quêtes, tes liens, ta propre aventure.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <GameProvider>{children}</GameProvider>
      </body>
    </html>
  );
}
