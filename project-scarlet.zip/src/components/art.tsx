"use client";
import { useState } from "react";
import Link from "next/link";
export function RoomScene() {
  return (
    <div className="room-scene" aria-label="Ta chambre interactive">
      <div className="room-world">
        <div className="room-floor" />
        <div className="room-wall back-wall" />
        <div className="room-wall side-wall" />
        <div className="room-window">
          <span>☾</span>
        </div>
        <div className="room-rug" />
        <div className="room-desk">
          <div className="desk-front" />
          <Link
            className="room-book"
            href="/journal"
            aria-label="Ouvrir le journal sur le bureau"
          >
            JOURNAL
            <br />✦
          </Link>
          <div className="room-lamp" />
        </div>
        <Link
          className="room-poster"
          href="/quetes"
          aria-label="Ouvrir les quêtes sur le mur"
        >
          MAKE
          <br />
          YOUR
          <br />
          <b>MOVE.</b>
        </Link>
        <Link
          className="room-shelf"
          href="/compendium"
          aria-label="Explorer le Compendium dans la bibliothèque"
        >
          <i />
          <i />
          <i />
          <span>COMPENDIUM</span>
        </Link>
      </div>
      <span className="room-hint">
        LE BUREAU, L’AFFICHE ET LA BIBLIOTHÈQUE T’ATTENDENT ↗
      </span>
    </div>
  );
}
export function City({ compact = false }: { compact?: boolean }) {
  return (
    <svg
      className={compact ? "city compact" : "city"}
      viewBox="0 0 800 480"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <pattern
          id={compact ? "windows-small" : "windows"}
          width="19"
          height="27"
          patternUnits="userSpaceOnUse"
        >
          <rect
            x="6"
            y="5"
            width="4"
            height="10"
            fill="#c63848"
            opacity=".55"
          />
        </pattern>
        <pattern
          id={compact ? "dots-small" : "dots"}
          width="7"
          height="7"
          patternUnits="userSpaceOnUse"
        >
          <circle cx="2" cy="2" r="1" fill="#07080c" opacity=".4" />
        </pattern>
      </defs>
      <circle cx="530" cy="192" r="146" fill="#e4324c" />
      <circle
        cx="530"
        cy="192"
        r="146"
        fill={`url(#${compact ? "dots-small" : "dots"})`}
      />
      <path
        d="M340 80 675 30 626 55 735 47 418 126Z"
        fill="#f5ded0"
        opacity=".7"
      />
      <g className="skyline-back" fill="#38141f">
        {Array.from({ length: 17 }, (_, i) => {
          const h = 60 + ((i * 79) % 145);
          return (
            <rect
              key={i}
              x={i * 52 - 10}
              y={360 - h}
              width="43"
              height={h + 100}
            />
          );
        })}
      </g>
      <g className="skyline-front">
        {Array.from({ length: 13 }, (_, i) => {
          const h = 70 + ((i * 67) % 210);
          return (
            <g key={i}>
              <path
                d={`M${i * 68 - 15} 470V${430 - h}l48 -16v${h + 56}Z`}
                fill="#0c0e14"
              />
              <path
                d={`M${i * 68 - 10} 440V${430 - h}l38 -12v${h + 22}Z`}
                fill={`url(#${compact ? "windows-small" : "windows"})`}
              />
              <path
                d={`M${i * 68 + 33} ${414 - h}l14 13v43l-14 4Z`}
                fill="#4f2430"
              />
            </g>
          );
        })}
      </g>
      <path d="m457 480 34-178 22-25 30 13 24 190z" fill="#030509" />
      <path
        d="m484 341-54 98 30-10 44-73m40-26 40 71 21 5-52-102"
        stroke="#030509"
        strokeWidth="19"
      />
      <path d="m505 278-6-29 11-23 21-5 18 17-4 26-17 19z" fill="#08090e" />
      <path d="m506 263 42-5-9 9-31 3z" fill="#edb7a2" />
      <path d="m490 289 60-6 53 47-55-18-14 17-35-29-59 17z" fill="#f43c53" />
      <path d="m510 316-20 135 37-30 28 40-15-142z" fill="#161820" />
      <path d="M0 464 800 442v38H0Z" fill="#050609" />
      <g fill="#efcfbb">
        <path d="m714 123 5 13 14 1-11 8 3 14-11-9-12 8 4-14-10-9 14 1z" />
        <path d="m307 167 3 7 8 1-6 4 1 8-6-5-6 4 2-7-5-5 7 1z" />
      </g>
    </svg>
  );
}
export function Tilt({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  return (
    <div
      className={`tilt ${className}`}
      onPointerMove={(e) => {
        if (e.pointerType !== "mouse") return;
        const r = e.currentTarget.getBoundingClientRect();
        setPosition({
          x: ((e.clientX - r.left) / r.width - 0.5) * 5,
          y: ((e.clientY - r.top) / r.height - 0.5) * -5,
        });
      }}
      onPointerLeave={() => setPosition({ x: 0, y: 0 })}
      style={{
        transform: `perspective(1000px) rotateX(${position.y}deg) rotateY(${position.x}deg)`,
      }}
    >
      {children}
    </div>
  );
}
