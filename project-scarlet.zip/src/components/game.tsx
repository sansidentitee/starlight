"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useEffect, type ReactNode, type FormEvent } from "react";
import { AnimatePresence, motion, MotionConfig } from "framer-motion";
import {
  ArrowUpRight,
  ArrowRight,
  Star,
  Sword,
  CalendarDays,
  Users,
  Castle,
  Radar,
  Sparkles,
  BookOpen,
  Library,
  Armchair,
  Settings,
  Home,
  Check,
  Plus,
  ChevronLeft,
  ChevronRight,
  X,
  Menu,
  Moon,
  Zap,
  LogOut,
  Cloud,
  Shield,
  Flag,
} from "lucide-react";
import { useGame } from "./game-provider";
import { City, Tilt, RoomScene } from "./art";
import {
  completeQuest,
  completePalaceStep,
  recordContact,
  localDate,
  level,
  statNames,
  type Stat,
  type Quest,
} from "@/lib/game";
import { supabase } from "@/lib/supabase";
const navigation = [
  ["accueil", "Le repaire", Home],
  ["quetes", "Quêtes", Sword],
  ["calendrier", "Calendrier", CalendarDays],
  ["confidants", "Confidants", Users],
  ["palais", "Palais", Castle],
  ["mementos", "Mementos", Radar],
  ["stats", "Stats sociales", Sparkles],
  ["journal", "Journal", BookOpen],
  ["compendium", "Compendium", Library],
  ["chambre", "Chambre", Armchair],
] as const;
const colors = ["#65c5d4", "#ed815e", "#c3a4ff", "#e6c266", "#9dc391"];
function Button({
  children,
  onClick,
  secondary = false,
  disabled = false,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  secondary?: boolean;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      className={`button ${secondary ? "secondary" : ""}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}
function SectionTitle({
  title,
  eyebrow,
  href,
}: {
  title: string;
  eyebrow?: string;
  href?: string;
}) {
  return (
    <div className="section-title">
      <div>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h2>
          {title}
          <span className="red">.</span>
        </h2>
      </div>
      {href && (
        <Link href={href} aria-label={`Ouvrir ${title}`} className="icon-link">
          <ArrowUpRight size={19} />
        </Link>
      )}
    </div>
  );
}
function Progress({ value, label }: { value: number; label: string }) {
  return (
    <div
      className="progress"
      role="progressbar"
      aria-label={label}
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <i style={{ width: `${Math.min(100, value)}%` }} />
    </div>
  );
}
export function Game({ page }: { page: string }) {
  const { state, ready, error, retry, user, status, toast } = useGame();
  const [menu, setMenu] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
  }, []);
  useEffect(() => setMenu(false), [page]);
  if (!ready)
    return (
      <main className="loading">
        <Star size={60} />
        <h1>PROJECT SCARLET</h1>
        <p>{error || "Ouverture du passage…"}</p>
        {error && <Button onClick={retry}>Réessayer</Button>}
      </main>
    );
  if (page === "connexion") return <Auth />;
  if (page === "onboarding" || !state.onboarded) return <Onboarding />;
  const title =
    navigation.find((n) => n[0] === page)?.[1] ||
    (page === "profil" ? "Identité" : "Paramètres");
  return (
    <MotionConfig reducedMotion={state.lowMotion ? "always" : "user"}>
      <div
        className={`game ${state.lowMotion ? "low-motion" : ""} ${state.accent === "moon" ? "moon-theme" : ""}`}
      >
        <a href="#main" className="skip">
          Aller au contenu
        </a>
        <aside className={`sidebar ${menu ? "open" : ""}`}>
          <Link href="/" className="brand">
            <span className="brand-star">✦</span>
            <span>
              <small>PROJECT STARLIGHT</small>
              <strong>
                SCARLET<span>↗</span>
              </strong>
            </span>
          </Link>
          <div className="chapter">
            CHAPITRE 01 <span>ÉVEIL</span>
          </div>
          <nav aria-label="Navigation principale">
            {navigation.map(([id, label, Icon], i) => (
              <Link
                key={id}
                href={id === "accueil" ? "/" : `/${id}`}
                className={page === id ? "active" : ""}
                aria-current={page === id ? "page" : undefined}
              >
                <Icon size={18} />
                <span>{label}</span>
                <small>{String(i + 1).padStart(2, "0")}</small>
              </Link>
            ))}
          </nav>
          <div className="sidebar-bottom">
            <Link href="/parametres">
              <Settings size={17} /> Paramètres
            </Link>
            <Link href="/profil" className="identity">
              <span className="avatar">
                {state.name.charAt(0).toUpperCase()}
              </span>
              <span>
                <strong>{state.name}</strong>
                <small>NIV. {level(state.xp)} · L’ÉTINCELLE</small>
              </span>
              <ArrowUpRight size={17} />
            </Link>
          </div>
        </aside>
        {menu && (
          <button
            className="nav-backdrop"
            aria-label="Fermer le menu"
            onClick={() => setMenu(false)}
          />
        )}
        <div className="workspace">
          <header className="topbar">
            <button
              className="mobile-menu"
              aria-expanded={menu}
              onClick={() => setMenu(!menu)}
              aria-label="Ouvrir le menu"
            >
              <Menu />
            </button>
            <div className="breadcrumb">
              LE MONDE T’APPARTIENT <span>/</span> <b>{title}</b>
            </div>
            <div className="top-right">
              <span className="save-status">
                <i /> {user ? status : "PARTIE LOCALE"}
              </span>
              <Link href={user ? "/profil" : "/connexion"}>
                {user ? "MON PROFIL" : "SE CONNECTER"}{" "}
                <ArrowUpRight size={14} />
              </Link>
            </div>
          </header>
          <main id="main" className="main">
            <AnimatePresence mode="wait">
              <motion.div
                key={page}
                initial={{ opacity: 0, x: 14 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
              >
                {page === "accueil" ? (
                  <Dashboard now={now} />
                ) : (
                  <>
                    <div className="page-heading">
                      <span className="eyebrow">
                        PROJECT STARLIGHT / TON HISTOIRE
                      </span>
                      <h1>
                        {title}
                        <span className="red">↗</span>
                      </h1>
                      <p>{descriptions[page]}</p>
                    </div>
                    <PageContent page={page} />
                  </>
                )}
              </motion.div>
            </AnimatePresence>
            <footer>
              TA VIE. TES RÈGLES. TON HISTOIRE.
              <span>
                PROJECT SCARLET <span className="red">✦</span> VOL. 01
              </span>
            </footer>
          </main>
        </div>
        <AnimatePresence>
          {toast && (
            <motion.div
              className="toast"
              role="status"
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <Sparkles size={19} />
              {toast}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </MotionConfig>
  );
}
const descriptions: Record<string, string> = {
  quetes: "Chaque petit pas peut changer la suite.",
  calendrier: "Le temps passe. Choisis ce que tu en fais.",
  confidants: "Les liens que tu cultives deviennent ta force.",
  palais: "Les grands changements commencent par une porte.",
  mementos: "Descends dans les petites choses laissées en suspens.",
  stats: "Tes actions dessinent la personne que tu deviens.",
  journal: "Laisse une trace. Même les jours ordinaires comptent.",
  compendium: "Les fragments de ton aventure, réunis ici.",
  chambre: "Un endroit pour souffler avant la prochaine aventure.",
  parametres: "Une expérience à ton rythme.",
  profil: "Derrière le nom de code, il y a toi.",
};
function Dashboard({ now }: { now: Date | null }) {
  const { state } = useGame();
  const pending = state.quests.filter((q) => !q.done && q.kind === "quest");
  return (
    <>
      <section className="hero">
        <div className="hero-lines" />
        <City />
        <div className="hero-content">
          <div className="hero-kicker">
            <span className="live-dot" /> UNE NOUVELLE JOURNÉE COMMENCE
          </div>
          <p className="hello">Bienvenue au repaire, {state.name}.</p>
          <h1>
            LE PROCHAIN
            <br />
            CHAPITRE,
            <br />
            <em>C’EST TOI.</em>
          </h1>
          <p className="hero-description">
            Les petites actions font les grandes histoires.
            <br />
            Quelle sera la tienne aujourd’hui ?
          </p>
          <Link className="button" href="/quetes">
            CONTINUER L’AVENTURE <ArrowRight size={19} />
          </Link>
          <div className="hero-meta">
            <span>CH. 01 — L’ÉVEIL</span>
            <span>★ {pending.length} QUÊTES DISPONIBLES</span>
          </div>
        </div>
        <div className="date-card">
          <strong>
            {now ? String(now.getDate()).padStart(2, "0") : "—"}
            <small>
              /{now ? String(now.getMonth() + 1).padStart(2, "0") : "—"}
            </small>
          </strong>
          <span>
            {now?.toLocaleDateString("fr-FR", { weekday: "long" }) ||
              "AUJOURD’HUI"}
          </span>
          <div>
            <Moon size={13} /> À TON RYTHME
          </div>
        </div>
        <div className="scene-caption">
          LA VILLE DES POSSIBLES <span>35° / SECTEUR 01</span>
        </div>
      </section>
      <div className="player-strip">
        <div className="level">
          <span>NIV.</span>
          <strong>{String(level(state.xp)).padStart(2, "0")}</strong>
        </div>
        <div className="xp">
          <div>
            <b>L’ÉTINCELLE</b>
            <span>
              {state.xp % 250} <small>/ 250 XP</small>
            </span>
          </div>
          <Progress
            value={((state.xp % 250) / 250) * 100}
            label="Expérience vers le prochain niveau"
          />
        </div>
        <span className="strip-quote">
          « Rien ne change sans un premier pas. »
        </span>
        <Link href="/profil" className="icon-link">
          <ArrowUpRight size={20} />
        </Link>
      </div>
      <div className="dashboard-grid">
        <section className="panel quest-panel">
          <SectionTitle
            title="À toi de jouer"
            eyebrow="QUÊTES DU JOUR"
            href="/quetes"
          />
          <div className="quest-list">
            {pending.slice(0, 3).map((q) => (
              <QuestRow key={q.id} quest={q} />
            ))}
            {pending.length === 0 && (
              <Empty text="Toutes tes quêtes sont accomplies. Savoure la victoire." />
            )}
          </div>
          <Link href="/quetes" className="text-link">
            LE TABLEAU DES QUÊTES <ArrowRight size={15} />
          </Link>
        </section>
        <PalaceCard />
        <section className="panel calendar-preview">
          <SectionTitle
            title="Ton prochain mouvement"
            eyebrow="CALENDRIER"
            href="/calendrier"
          />
          <Week />
          <div className="appointment">
            <span>PROCHAINE QUÊTE</span>
            <strong>{pending[0]?.title || "Un peu de temps pour toi"}</strong>
            <small>{pending[0]?.date || "Aucune quête prévue"}</small>
          </div>
        </section>
        <section className="panel mementos-preview">
          <SectionTitle
            title="Mementos"
            eyebrow="SOUS LA SURFACE"
            href="/mementos"
          />
          <Link
            href="/mementos"
            className="mini-map"
            aria-label="Explorer Mementos"
          >
            <div className="rail" />
            {[0, 1, 2, 3, 4].map((n) => (
              <span
                key={n}
                className={n === 0 ? "station current" : "station"}
                style={{ left: `${12 + n * 18}%`, top: `${n % 2 ? 43 : 57}%` }}
              >
                {n === 0 ? <Radar size={20} /> : n + 1}
              </span>
            ))}
          </Link>
          <div className="panel-bottom">
            <span>
              {
                state.quests.filter((q) => q.kind === "mementos" && !q.done)
                  .length
              }{" "}
              requêtes dans les profondeurs
            </span>
            <Link href="/mementos">EXPLORER ↗</Link>
          </div>
        </section>
        <section className="panel stats-preview">
          <SectionTitle
            title="Ce qui te rend unique"
            eyebrow="STATS SOCIALES"
            href="/stats"
          />
          <Stats compact />
        </section>
        <section className="panel confidants-preview">
          <SectionTitle
            title="Jamais seul"
            eyebrow="CONFIDANTS"
            href="/confidants"
          />
          {state.confidants.length ? (
            <div className="faces">
              {state.confidants.slice(0, 4).map((c, i) => (
                <Link href="/confidants" key={c.id}>
                  <span
                    className="portrait"
                    style={{ background: colors[i % 5] }}
                  >
                    {c.name[0]}
                  </span>
                  <strong>{c.name}</strong>
                  <small>RANG {c.rank}</small>
                </Link>
              ))}
            </div>
          ) : (
            <div className="friend-empty">
              <Users size={34} />
              <p>
                Chaque rencontre peut
                <br />
                ouvrir un nouveau chemin.
              </p>
              <Link href="/confidants" className="text-link">
                CRÉER UN LIEN <Plus size={15} />
              </Link>
            </div>
          )}
        </section>
        <Link href="/journal" className="panel journal-preview">
          <BookOpen size={27} />
          <div>
            <span className="eyebrow">UNE PAGE À LA FOIS</span>
            <h2>Garde une trace.</h2>
            <p>Qu’as-tu envie de retenir d’aujourd’hui ?</p>
          </div>
          <ArrowUpRight />
        </Link>
        <Link href="/chambre" className="panel room-preview">
          <Armchair size={35} />
          <div>
            <span className="eyebrow">TA SAFE ROOM</span>
            <h2>Respire un peu.</h2>
            <p>La suite peut attendre un instant.</p>
          </div>
          <ArrowUpRight />
        </Link>
      </div>
    </>
  );
}
function QuestRow({ quest }: { quest: Quest }) {
  const { update, notify } = useGame();
  const index = statNames.indexOf(quest.stat);
  return (
    <div className={`quest-row ${quest.done ? "done" : ""}`}>
      <button
        aria-label={`Accomplir : ${quest.title}`}
        disabled={quest.done}
        className="quest-check"
        onClick={() => {
          update((s) => completeQuest(s, quest.id));
          notify(`QUÊTE ACCOMPLIE · +${quest.xp} XP · ${quest.stat}`);
        }}
      >
        {quest.done ? <Check size={17} /> : <Sword size={17} />}
      </button>
      <div>
        <strong>{quest.title}</strong>
        <small>
          <i style={{ background: colors[index] }} />
          {quest.stat}{" "}
          <span>· {quest.kind === "mementos" ? "REQUÊTE" : "MISSION"}</span>
        </small>
      </div>
      <span className="quest-xp">
        {quest.done ? "✓" : `+${quest.xp}`}
        <small>{quest.done ? "FAIT" : "XP"}</small>
      </span>
    </div>
  );
}
function PalaceCard() {
  const { state } = useGame();
  const p = state.palaces[0];
  return (
    <Tilt className="palace-tilt">
      <Link className="panel palace-card" href="/palais">
        <City compact />
        <div className="palace-content">
          <span className="tag">PALAIS ACTIF</span>
          <h2>{p?.title || "Un nouveau Palais"}</h2>
          <p>{p?.subtitle || "Donne une forme à ton prochain objectif"}</p>
          <div className="palace-progress">
            <span>INFILTRATION</span>
            <strong>
              {p ? Math.round((p.completed / p.steps.length) * 100) : 0}%
            </strong>
          </div>
          <Progress
            value={p ? (p.completed / p.steps.length) * 100 : 0}
            label="Progression du Palais"
          />
          <div className="palace-enter">
            ENTRER DANS LE PALAIS <ArrowUpRight size={20} />
          </div>
        </div>
      </Link>
    </Tilt>
  );
}
function Week() {
  const today = new Date();
  return (
    <div className="week">
      {Array.from({ length: 7 }, (_, i) => {
        const d = new Date(today);
        d.setDate(today.getDate() - ((today.getDay() + 6) % 7) + i);
        return (
          <Link
            href="/calendrier"
            key={i}
            className={localDate(d) === localDate(today) ? "today" : ""}
          >
            <span>{["L", "M", "M", "J", "V", "S", "D"][i]}</span>
            <b>{d.getDate()}</b>
            <i />
          </Link>
        );
      })}
    </div>
  );
}
function Stats({ compact = false }: { compact?: boolean }) {
  const { state } = useGame();
  const pts = statNames
    .map((s, i) => {
      const angle = ((i * 72 - 90) * Math.PI) / 180;
      const radius = 20 + Math.min(state.stats[s] / 250, 1) * 58;
      return `${100 + Math.cos(angle) * radius},${100 + Math.sin(angle) * radius}`;
    })
    .join(" ");
  return (
    <div className={`stats ${compact ? "compact" : ""}`}>
      <svg
        viewBox="0 0 200 200"
        role="img"
        aria-label="Radar des cinq stats sociales"
      >
        {[28, 53, 78].map((r) => (
          <polygon
            key={r}
            points={statNames
              .map(
                (_, i) =>
                  `${100 + Math.cos(((i * 72 - 90) * Math.PI) / 180) * r},${100 + Math.sin(((i * 72 - 90) * Math.PI) / 180) * r}`,
              )
              .join(" ")}
            fill="none"
            stroke="#46424d"
          />
        ))}
        {statNames.map((_, i) => (
          <line
            key={i}
            x1="100"
            y1="100"
            x2={100 + Math.cos(((i * 72 - 90) * Math.PI) / 180) * 78}
            y2={100 + Math.sin(((i * 72 - 90) * Math.PI) / 180) * 78}
            stroke="#37333e"
          />
        ))}
        <polygon
          points={pts}
          fill="#d9385266"
          stroke="#ef5368"
          strokeWidth="2"
        />
        {statNames.map((_, i) => (
          <circle
            key={i}
            cx={100 + Math.cos(((i * 72 - 90) * Math.PI) / 180) * 78}
            cy={100 + Math.sin(((i * 72 - 90) * Math.PI) / 180) * 78}
            r="4"
            fill={colors[i]}
          />
        ))}
      </svg>
      <div className="stat-legend">
        {statNames.map((s, i) => (
          <div key={s}>
            <i style={{ background: colors[i] }} />
            <span>{s}</span>
            <b>{state.stats[s]}</b>
          </div>
        ))}
      </div>
    </div>
  );
}
function Empty({ text }: { text: string }) {
  return (
    <div className="empty">
      <Star size={25} />
      <p>{text}</p>
    </div>
  );
}
function PageContent({ page }: { page: string }) {
  switch (page) {
    case "quetes":
      return <Quests />;
    case "calendrier":
      return <Calendar />;
    case "palais":
      return <Palaces />;
    case "mementos":
      return <Mementos />;
    case "confidants":
      return <Confidants />;
    case "stats":
      return <StatsPage />;
    case "journal":
      return <Journal />;
    case "compendium":
      return <Compendium />;
    case "chambre":
      return <Room />;
    case "profil":
      return <Profile />;
    default:
      return <Preferences />;
  }
}
function QuestForm({
  kind = "quest",
  onClose,
  date = localDate(),
}: {
  kind?: "quest" | "mementos";
  onClose: () => void;
  date?: string;
}) {
  const { update, state } = useGame();
  return (
    <form
      className="form panel"
      onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        const title = String(f.get("title")).trim();
        if (!title) return;
        update((s) => ({
          ...s,
          quests: [
            ...s.quests,
            {
              id: crypto.randomUUID(),
              title,
              stat: f.get("stat") as Stat,
              xp: kind === "quest" ? 30 : 15,
              done: false,
              date: String(f.get("date")),
              kind,
              palace: String(f.get("palace") || "") || undefined,
            },
          ],
        }));
        onClose();
      }}
    >
      <div className="section-title">
        <h2>Nouvelle {kind === "quest" ? "quête" : "requête"}</h2>
        <button
          type="button"
          className="icon-link"
          onClick={onClose}
          aria-label="Fermer"
        >
          <X />
        </button>
      </div>
      <label>
        Ta prochaine action
        <input
          name="title"
          maxLength={140}
          required
          placeholder="Un petit pas concret…"
          autoFocus
        />
      </label>
      <div className="form-grid">
        <label>
          Stat à développer
          <select name="stat">
            {statNames.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <label>
          À quelle date ?
          <input name="date" type="date" defaultValue={date} required />
        </label>
      </div>
      <label>
        Palais associé
        <select name="palace">
          <option value="">Quête indépendante</option>
          {state.palaces.map((p) => (
            <option key={p.id} value={p.id}>
              {p.title}
            </option>
          ))}
        </select>
      </label>
      <Button type="submit">
        AJOUTER · +{kind === "quest" ? 30 : 15} XP <Plus size={16} />
      </Button>
    </form>
  );
}
function Quests() {
  const { state } = useGame();
  const [filter, setFilter] = useState("active");
  const [adding, setAdding] = useState(false);
  const quests = state.quests.filter(
    (q) =>
      q.kind === "quest" &&
      (filter === "all" || q.done === (filter === "done")),
  );
  return (
    <>
      <div className="toolbar">
        <div className="tabs">
          {[
            ["active", "En cours"],
            ["done", "Accomplies"],
            ["all", "Toutes"],
          ].map(([id, label]) => (
            <button
              key={id}
              className={filter === id ? "selected" : ""}
              onClick={() => setFilter(id)}
            >
              {label}
            </button>
          ))}
        </div>
        <Button onClick={() => setAdding(true)}>
          <Plus size={16} /> NOUVELLE QUÊTE
        </Button>
      </div>
      {adding && <QuestForm onClose={() => setAdding(false)} />}
      <div className="panel large-list">
        {quests.map((q) => (
          <QuestRow key={q.id} quest={q} />
        ))}
        {!quests.length && <Empty text="Aucune quête ici pour le moment." />}
      </div>
    </>
  );
}
function Calendar() {
  const { state } = useGame();
  const [offset, setOffset] = useState(0);
  const [selected, setSelected] = useState(localDate());
  const [adding, setAdding] = useState(false);
  const today = new Date();
  const month = new Date(today.getFullYear(), today.getMonth() + offset, 1);
  const start = (month.getDay() + 6) % 7;
  const count = new Date(
    month.getFullYear(),
    month.getMonth() + 1,
    0,
  ).getDate();
  const quests = state.quests.filter((q) => q.date === selected);
  return (
    <div className="two-columns">
      <section className="panel calendar-full">
        <div className="section-title">
          <button
            className="icon-link"
            aria-label="Mois précédent"
            onClick={() => setOffset((o) => o - 1)}
          >
            <ChevronLeft />
          </button>
          <h2>
            {month.toLocaleDateString("fr-FR", {
              month: "long",
              year: "numeric",
            })}
          </h2>
          <button
            className="icon-link"
            aria-label="Mois suivant"
            onClick={() => setOffset((o) => o + 1)}
          >
            <ChevronRight />
          </button>
        </div>
        <div className="month-grid">
          {["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"].map((d) => (
            <span key={d}>{d}</span>
          ))}
          {Array.from({ length: start }, (_, i) => (
            <div key={`blank${i}`} />
          ))}
          {Array.from({ length: count }, (_, i) => {
            const date = localDate(
              new Date(month.getFullYear(), month.getMonth(), i + 1),
            );
            return (
              <button
                key={date}
                aria-label={date}
                aria-pressed={selected === date}
                className={`${selected === date ? "selected" : ""} ${date === localDate() ? "is-today" : ""}`}
                onClick={() => setSelected(date)}
              >
                <b>{i + 1}</b>
                {state.quests.some((q) => q.date === date) && <i />}
              </button>
            );
          })}
        </div>
      </section>
      <section className="panel">
        <SectionTitle title="Au programme" eyebrow={selected} />
        {quests.map((q) => (
          <QuestRow key={q.id} quest={q} />
        ))}
        {!quests.length && (
          <Empty text="Une page libre. À toi d’y écrire la suite." />
        )}
        <Button secondary onClick={() => setAdding(!adding)}>
          PLANIFIER UNE QUÊTE <Plus size={16} />
        </Button>
        {adding && (
          <QuestForm
            key={selected}
            date={selected}
            onClose={() => setAdding(false)}
          />
        )}
      </section>
    </div>
  );
}
function Palaces() {
  const { state, update, notify } = useGame();
  const [adding, setAdding] = useState(false);
  return (
    <>
      <div className="toolbar">
        <p>{state.palaces.length} territoire(s) à explorer</p>
        <Button onClick={() => setAdding(!adding)}>
          NOUVEAU PALAIS <Plus size={16} />
        </Button>
      </div>
      {adding && (
        <form
          className="panel form"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            const steps = String(f.get("steps"))
              .split("\n")
              .map((s) => s.trim())
              .filter(Boolean);
            const title = String(f.get("title")).trim();
            if (!title || !steps.length) return;
            update((s) => ({
              ...s,
              palaces: [
                ...s.palaces,
                {
                  id: crypto.randomUUID(),
                  title,
                  subtitle: String(f.get("subtitle")).trim(),
                  steps,
                  completed: 0,
                },
              ],
            }));
            setAdding(false);
          }}
        >
          <label>
            Nom du Palais
            <input
              name="title"
              required
              maxLength={80}
              placeholder="La Tour des Possibles"
            />
          </label>
          <label>
            Ton objectif
            <input name="subtitle" required maxLength={180} />
          </label>
          <label>
            Les étapes — une par ligne
            <textarea
              name="steps"
              required
              maxLength={2000}
              placeholder={"Trouver une idée\nCréer un prototype\nLe partager"}
            />
          </label>
          <Button type="submit">OUVRIR LE PASSAGE</Button>
        </form>
      )}
      <div className="palace-list">
        {state.palaces.map((p) => (
          <section className="panel palace-detail" key={p.id}>
            <div className="palace-banner">
              <City compact />
              <div>
                <span className="eyebrow">
                  {p.completed === p.steps.length
                    ? "PALAIS CONQUIS"
                    : "INFILTRATION EN COURS"}
                </span>
                <h2>{p.title}</h2>
                <p>{p.subtitle}</p>
              </div>
              <strong>
                {Math.round((p.completed / p.steps.length) * 100)}
                <small>%</small>
              </strong>
            </div>
            <Progress
              value={(p.completed / p.steps.length) * 100}
              label={p.title}
            />
            <ol className="steps">
              {p.steps.map((step, i) => (
                <li
                  key={i}
                  className={
                    i < p.completed
                      ? "complete"
                      : i === p.completed
                        ? "current"
                        : ""
                  }
                >
                  <span>
                    {i < p.completed ? (
                      <Check size={16} />
                    ) : (
                      String(i + 1).padStart(2, "0")
                    )}
                  </span>
                  <div>
                    <strong>{step}</strong>
                    <small>
                      {i < p.completed
                        ? "ÉTAPE ACCOMPLIE"
                        : i === p.completed
                          ? "PROCHAINE ÉTAPE"
                          : "À VENIR"}
                    </small>
                  </div>
                  {i === p.completed && (
                    <Button
                      secondary
                      onClick={() => {
                        update((s) => completePalaceStep(s, p.id, p.completed));
                        notify("PASSAGE OUVERT · +75 XP");
                      }}
                    >
                      ACCOMPLIR <Check size={15} />
                    </Button>
                  )}
                </li>
              ))}
            </ol>
            <div className="linked-quests">
              <span className="eyebrow">QUÊTES ASSOCIÉES</span>
              {state.quests
                .filter((q) => q.palace === p.id)
                .map((q) => (
                  <QuestRow key={q.id} quest={q} />
                ))}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
function Mementos() {
  const { state } = useGame();
  const [adding, setAdding] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const quests = state.quests.filter((q) => q.kind === "mementos");
  const current = quests.find((q) => q.id === selected);
  return (
    <>
      <div className="toolbar">
        <p>
          {quests.filter((q) => q.done).length} / {quests.length} requêtes
          résolues
        </p>
        <Button onClick={() => setAdding(!adding)}>
          NOUVELLE REQUÊTE <Plus size={16} />
        </Button>
      </div>
      {adding && <QuestForm kind="mementos" onClose={() => setAdding(false)} />}
      <section className="panel underground">
        <div className="underground-label">
          <span className="eyebrow">RÉSEAU DES OMBRES</span>
          <h2>
            Chaque détour
            <br />
            te fait avancer.
          </h2>
          <p>Sélectionne une station pour explorer sa requête.</p>
        </div>
        <div className="stations">
          {quests.map((q, i) => (
            <button
              key={q.id}
              className={`map-node ${q.done ? "cleared" : ""} ${selected === q.id ? "selected" : ""}`}
              onClick={() => setSelected(q.id)}
            >
              <span>{q.done ? <Check /> : <Radar />}</span>
              <b>ZONE {String(i + 1).padStart(2, "0")}</b>
              <small>{q.done ? "RÉSOLUE" : q.title}</small>
            </button>
          ))}
        </div>
      </section>
      {current ? (
        <section className="panel">
          <SectionTitle title="Requête sélectionnée" />
          <QuestRow quest={current} />
        </section>
      ) : (
        <p className="muted">
          Les stations représentent tes petites tâches. Tu peux les résoudre
          dans l’ordre de ton choix.
        </p>
      )}
    </>
  );
}
function Confidants() {
  const { state, update, notify } = useGame();
  const [adding, setAdding] = useState(false);
  return (
    <>
      <div className="toolbar">
        <p>Du temps partagé, des liens plus forts.</p>
        <Button onClick={() => setAdding(!adding)}>
          CRÉER UN LIEN <Plus size={16} />
        </Button>
      </div>
      {adding && (
        <form
          className="panel form"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            const name = String(f.get("name")).trim();
            if (!name) return;
            update((s) => ({
              ...s,
              confidants: [
                ...s.confidants,
                {
                  id: crypto.randomUUID(),
                  name,
                  role: String(f.get("role")).trim(),
                  rank: 1,
                  lastContact: "",
                },
              ],
            }));
            setAdding(false);
          }}
        >
          <label>
            Prénom ou surnom
            <input name="name" required maxLength={40} />
          </label>
          <label>
            Votre lien
            <input
              name="role"
              required
              placeholder="Amitié, famille, mentor…"
              maxLength={60}
            />
          </label>
          <Button type="submit">NOUVELLE ALLIANCE</Button>
        </form>
      )}
      <div className="confidant-grid">
        {state.confidants.map((c, i) => (
          <Tilt key={c.id}>
            <section className="panel confidant-card">
              <div
                className="confidant-art"
                style={{ "--portrait": colors[i % 5] } as React.CSSProperties}
              >
                <span className="arcana">
                  ARCANE {String(i + 1).padStart(2, "0")}
                </span>
                <span>{c.name[0].toUpperCase()}</span>
                <Star size={80} />
              </div>
              <span className="eyebrow">{c.role}</span>
              <h2>{c.name}</h2>
              <div className="rank">
                <span>RANG</span>
                <b>{String(c.rank).padStart(2, "0")}</b>
                <small>/ 10</small>
              </div>
              <Progress value={c.rank * 10} label={`Rang de ${c.name}`} />
              <p>
                {c.lastContact
                  ? `Dernier moment : ${c.lastContact}`
                  : "Un lien à cultiver, à ton rythme."}
              </p>
              <Button
                disabled={c.lastContact === localDate() || c.rank === 10}
                onClick={() => {
                  update((s) => recordContact(s, c.id));
                  notify("LIEN RENFORCÉ · +20 XP · +20 Empathie");
                }}
              >
                {c.rank === 10
                  ? "LIEN PRÉCIEUX"
                  : c.lastContact === localDate()
                    ? "MOMENT ENREGISTRÉ"
                    : "UN MOMENT PARTAGÉ"}{" "}
                <Users size={16} />
              </Button>
            </section>
          </Tilt>
        ))}
      </div>
      {!state.confidants.length && (
        <Empty text="Ajoute une personne qui compte pour toi. Aucun message ne lui sera envoyé." />
      )}
    </>
  );
}
function StatsPage() {
  const { state } = useGame();
  return (
    <div className="two-columns">
      <section className="panel">
        <SectionTitle
          title="Ton empreinte"
          eyebrow="CINQ FACETTES, UNE HISTOIRE"
        />
        <Stats />
        <p className="muted">
          Chaque quête accomplie développe sa stat associée. Un rang tous les
          100 points, jusqu’au rang 5.
        </p>
      </section>
      <div className="stat-cards">
        {statNames.map((s, i) => (
          <section className="panel" key={s}>
            <div className="section-title">
              <h2 style={{ color: colors[i] }}>{s}</h2>
              <b>RANG {Math.min(5, Math.floor(state.stats[s] / 100) + 1)}</b>
            </div>
            <Progress
              value={Math.min((state.stats[s] / 400) * 100, 100)}
              label={s}
            />
            <p>
              {state.stats[s]} points ·{" "}
              {
                [
                  "Explore, lis, apprends.",
                  "Ose ce premier pas.",
                  "Donne une voix à tes idées.",
                  "Reviens, même pour vingt minutes.",
                  "Écoute et prends soin de tes liens.",
                ][i]
              }
            </p>
          </section>
        ))}
      </div>
    </div>
  );
}
function Journal() {
  const { state, update, notify } = useGame();
  return (
    <div className="two-columns">
      <form
        className="panel form"
        onSubmit={(e) => {
          e.preventDefault();
          const f = new FormData(e.currentTarget);
          const text = String(f.get("text")).trim();
          if (!text) return;
          update((s) => ({
            ...s,
            journal: [
              {
                id: crypto.randomUUID(),
                date: new Date().toISOString(),
                mood: String(f.get("mood")),
                text,
              },
              ...s.journal,
            ],
          }));
          e.currentTarget.reset();
          notify("UNE PAGE DE PLUS DANS TON HISTOIRE");
        }}
      >
        <SectionTitle title="Cher moi de demain…" eyebrow={localDate()} />
        <label>
          Comment tu te sens ?
          <select name="mood">
            {[
              "Serein",
              "Motivé",
              "Fier",
              "Fatigué",
              "Perdu",
              "Reconnaissant",
            ].map((m) => (
              <option key={m}>{m}</option>
            ))}
          </select>
        </label>
        <label>
          Ce que je veux retenir
          <textarea
            name="text"
            required
            maxLength={6000}
            rows={9}
            placeholder="Une victoire, un doute, quelque chose de beau…"
          />
        </label>
        <Button type="submit">
          ENREGISTRER CETTE PAGE <BookOpen size={17} />
        </Button>
        <small>
          Ton journal est personnel, accessible uniquement depuis ton compte ou
          ce navigateur en mode local.
        </small>
      </form>
      <div className="journal-entries">
        {state.journal.map((j) => (
          <article className="panel" key={j.id}>
            <span className="eyebrow">
              {new Date(j.date).toLocaleDateString("fr-FR", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}{" "}
              · {j.mood}
            </span>
            <p>{j.text}</p>
          </article>
        ))}
        {!state.journal.length && (
          <Empty text="Ton histoire n’est pas encore écrite. Commence par une ligne." />
        )}
      </div>
    </div>
  );
}
function Compendium() {
  const { state } = useGame();
  const badges = [
    {
      title: "Première étincelle",
      description: "Accomplir une première quête.",
      done: state.quests.some((q) => q.done),
      icon: Zap,
    },
    {
      title: "Explorateur des ombres",
      description: "Résoudre trois requêtes de Mementos.",
      done:
        state.quests.filter((q) => q.kind === "mementos" && q.done).length >= 3,
      icon: Radar,
    },
    {
      title: "Le pouvoir des liens",
      description: "Créer un premier lien.",
      done: state.confidants.length > 0,
      icon: Users,
    },
    {
      title: "Auteur de ton histoire",
      description: "Écrire trois pages de journal.",
      done: state.journal.length >= 3,
      icon: BookOpen,
    },
    {
      title: "Briser les murs",
      description: "Conquérir un Palais.",
      done: state.palaces.some((p) => p.completed === p.steps.length),
      icon: Castle,
    },
    {
      title: "Une nouvelle lumière",
      description: "Atteindre le niveau 5.",
      done: level(state.xp) >= 5,
      icon: Star,
    },
  ];
  return (
    <div className="badge-grid">
      {badges.map(({ title, description, done, icon: Icon }) => (
        <section
          key={title}
          className={`panel badge ${done ? "unlocked" : ""}`}
        >
          <Icon size={48} />
          <span className="eyebrow">
            {done ? "FRAGMENT DÉCOUVERT" : "À DÉCOUVRIR"}
          </span>
          <h2>{title}</h2>
          <p>{description}</p>
          {done && <Check size={20} />}
        </section>
      ))}
    </div>
  );
}
function Room() {
  const { state, update } = useGame();
  const [breathing, setBreathing] = useState(false);
  return (
    <div className="two-columns">
      <section className="panel safe-room">
        <span className="eyebrow">AUCUN OBJECTIF ICI</span>
        <h2>
          Tu peux juste
          <br />
          être là.
        </h2>
        <RoomScene />
        <div className={`breathing-orb ${breathing ? "breathing" : ""}`}>
          <Moon size={50} />
        </div>
        <p>
          {breathing
            ? "Inspire quand le cercle grandit, expire quand il rétrécit."
            : "Un instant de calme. Rien à gagner, rien à prouver."}
        </p>
        <Button secondary onClick={() => setBreathing(!breathing)}>
          {breathing ? "TERMINER LA PAUSE" : "PRENDRE UNE PAUSE"}
        </Button>
      </section>
      <section className="panel form">
        <SectionTitle title="Ton atmosphère" />
        <p>Un repaire qui te ressemble.</p>
        <div className="theme-options">
          <button
            className={state.accent === "scarlet" ? "selected" : ""}
            onClick={() => update((s) => ({ ...s, accent: "scarlet" }))}
          >
            <span style={{ background: "#b91838" }} />
            Nuit écarlate
          </button>
          <button
            className={state.accent === "moon" ? "selected" : ""}
            onClick={() => update((s) => ({ ...s, accent: "moon" }))}
          >
            <span style={{ background: "#7963ad" }} />
            Lune violette
          </button>
        </div>
        <Link href="/journal" className="button secondary">
          DÉPOSER UNE PENSÉE <ArrowUpRight size={17} />
        </Link>
      </section>
    </div>
  );
}
function Profile() {
  const { state, update, notify, user } = useGame();
  return (
    <div className="two-columns">
      <section className="panel profile-card">
        <span className="profile-avatar">{state.name[0]?.toUpperCase()}</span>
        <span className="eyebrow">L’ÉTINCELLE</span>
        <h2>{state.name}</h2>
        <strong className="big-level">NIV. {level(state.xp)}</strong>
        <p>
          {state.xp} XP · {state.quests.filter((q) => q.done).length} quêtes
          accomplies
        </p>
        <Progress value={((state.xp % 250) / 250) * 100} label="Expérience" />
        <p>{user?.email || "Partie locale — sauvegardée sur ce navigateur"}</p>
        {!user && (
          <Link href="/connexion" className="button">
            CRÉER MON COMPTE <ArrowUpRight size={17} />
          </Link>
        )}
      </section>
      <form
        className="panel form"
        onSubmit={(e) => {
          e.preventDefault();
          const f = new FormData(e.currentTarget);
          const name = String(f.get("name")).trim();
          const objective = String(f.get("objective")).trim();
          if (!name || !objective) return;
          update((s) => ({ ...s, name, objective }));
          notify("IDENTITÉ MISE À JOUR");
        }}
      >
        <SectionTitle title="Derrière le nom de code" />
        <label>
          Ton nom de code
          <input
            name="name"
            defaultValue={state.name}
            required
            maxLength={30}
          />
        </label>
        <label>
          Ton objectif
          <textarea
            name="objective"
            defaultValue={state.objective}
            required
            maxLength={240}
          />
        </label>
        <Button type="submit">SAUVEGARDER MON PROFIL</Button>
      </form>
    </div>
  );
}
function Preferences() {
  const { state, update, status, retry, user, notify } = useGame();
  const router = useRouter();
  return (
    <section className="panel settings-panel">
      <div className="setting">
        <div>
          <h2>Animations légères</h2>
          <p>
            Réduit les mouvements, les effets de profondeur et la parallaxe.
          </p>
        </div>
        <input
          aria-label="Animations légères"
          type="checkbox"
          checked={state.lowMotion}
          onChange={(e) =>
            update((s) => ({ ...s, lowMotion: e.target.checked }))
          }
        />
      </div>
      <div className="setting">
        <div>
          <h2>
            <Cloud size={20} /> Sauvegarde
          </h2>
          <p>
            {user
              ? status
              : "Locale : conservée dans ce navigateur. Un compte permet la sauvegarde cloud."}
          </p>
        </div>
        {user ? (
          <Button secondary onClick={retry}>
            SYNCHRONISER
          </Button>
        ) : (
          <Link className="button secondary" href="/connexion">
            SE CONNECTER
          </Link>
        )}
      </div>
      <div className="setting">
        <div>
          <h2>Emporter ton histoire</h2>
          <p>Export JSON de ton profil et de toute ta progression.</p>
        </div>
        <Button
          secondary
          onClick={() => {
            const url = URL.createObjectURL(
              new Blob([JSON.stringify(state, null, 2)], {
                type: "application/json",
              }),
            );
            const a = document.createElement("a");
            a.href = url;
            a.download = `scarlet-${localDate()}.json`;
            a.click();
            URL.revokeObjectURL(url);
          }}
        >
          EXPORTER
        </Button>
      </div>
      <div className="setting">
        <div>
          <h2>Revoir le tutoriel</h2>
          <p>Retrouver les règles de ton aventure.</p>
        </div>
        <Link className="button secondary" href="/onboarding">
          REJOUER
        </Link>
      </div>
      {user && (
        <Button
          secondary
          onClick={async () => {
            const { error } = await supabase!.auth.signOut();
            if (error) notify(error.message);
            else router.push("/");
          }}
        >
          <LogOut size={16} /> SE DÉCONNECTER
        </Button>
      )}
    </section>
  );
}
function Onboarding() {
  const { state, update } = useGame();
  const router = useRouter();
  const [step, setStep] = useState(0);
  const slides = [
    {
      kicker: "LE CONTRAT / 01",
      title: "Et si ta vie devenait\nune aventure ?",
      text: "Pas besoin d’être quelqu’un d’autre. Choisis simplement une direction qui compte pour toi.",
      icon: Flag,
    },
    {
      kicker: "LE PREMIER PAS / 02",
      title: "Une quête.\nUn vrai changement.",
      text: "Transforme tes intentions en actions concrètes. Chaque quête accomplie te donne de l’XP et fait progresser une stat.",
      icon: Sword,
    },
    {
      kicker: "TON POTENTIEL / 03",
      title: "Tu as plus\nd’une facette.",
      text: "Connaissance, Courage, Expression, Discipline et Empathie : développe tes forces à travers tes actions, à ton rythme.",
      icon: Sparkles,
    },
    {
      kicker: "LES TERRITOIRES / 04",
      title: "Brise les murs.\nExplore les ombres.",
      text: "Les Palais sont tes grands projets, divisés en étapes. Mementos accueille les petites tâches qui encombrent ton esprit.",
      icon: Castle,
    },
    {
      kicker: "TON IDENTITÉ / 05",
      title: "Cette histoire\nporte ton nom.",
      text: "Un nom de code, une direction. Ton aventure peut commencer.",
      icon: Star,
    },
  ];
  const s = slides[step];
  const Icon = s.icon;
  return (
    <main className="onboarding">
      <Link href="/" className="brand">
        <span className="brand-star">✦</span>
        <span>
          <small>PROJECT STARLIGHT</small>
          <strong>SCARLET↗</strong>
        </span>
      </Link>
      <div className="onboard-art">
        <City />
        <span>
          TA VIE.
          <br />
          TES RÈGLES.
        </span>
      </div>
      <section className="onboard-content">
        <div className="onboard-steps">
          {slides.map((_, i) => (
            <span key={i} className={i <= step ? "active" : ""} />
          ))}
        </div>
        <Icon className="onboard-icon" size={40} />
        <span className="eyebrow">{s.kicker}</span>
        <h1>{s.title}</h1>
        <p>{s.text}</p>
        {step === 4 ? (
          <form
            className="form"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              const name = String(f.get("name")).trim();
              const objective = String(f.get("objective")).trim();
              if (!name || !objective) return;
              update((previous) => ({
                ...previous,
                name,
                objective,
                onboarded: true,
                palaces: previous.onboarded
                  ? previous.palaces
                  : previous.palaces.map((p) =>
                      p.id === "p1" ? { ...p, subtitle: objective } : p,
                    ),
              }));
              router.push("/");
            }}
          >
            <label>
              Ton nom de code
              <input
                name="name"
                required
                maxLength={30}
                defaultValue={state.name === "Voyageur" ? "" : state.name}
                placeholder="Comment t’appelle-t-on ?"
              />
            </label>
            <label>
              Ce que tu veux changer
              <input
                name="objective"
                required
                maxLength={240}
                defaultValue={state.onboarded ? state.objective : ""}
                placeholder="Créer, apprendre, me sentir mieux…"
              />
            </label>
            <Button type="submit">
              SIGNER MON HISTOIRE <ArrowRight size={18} />
            </Button>
            <small>Tu démarres en mode local si tu n’es pas connecté.</small>
          </form>
        ) : (
          <Button onClick={() => setStep(step + 1)}>
            {step === 0 ? "ENTRER DANS L’HISTOIRE" : "CONTINUER"}{" "}
            <ArrowRight size={18} />
          </Button>
        )}
        <div className="onboard-bottom">
          {step > 0 ? (
            <button onClick={() => setStep(step - 1)}>← RETOUR</button>
          ) : (
            <Link href="/connexion">J’AI DÉJÀ UN COMPTE</Link>
          )}
          <span>{String(step + 1).padStart(2, "0")} / 05</span>
        </div>
      </section>
    </main>
  );
}
function Auth() {
  const { user, notify } = useGame();
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup">("signup");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true);
    setMessage("");
    const f = new FormData(e.currentTarget);
    try {
      const credentials = {
        email: String(f.get("email")).trim(),
        password: String(f.get("password")),
      };
      const { data, error } =
        mode === "signup"
          ? await supabase.auth.signUp({
              ...credentials,
              options: {
                emailRedirectTo: window.location.origin + "/connexion",
              },
            })
          : await supabase.auth.signInWithPassword(credentials);
      if (error) throw error;
      if (data.session) {
        notify("CONNEXION ÉTABLIE");
        router.push("/");
      } else
        setMessage(
          "Vérifie ta boîte mail pour confirmer ton compte, puis connecte-toi.",
        );
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : "Connexion impossible. Réessaie.",
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="auth-screen">
      <div className="auth-art">
        <City />
        <h1>
          TON HISTOIRE.
          <br />
          <em>PARTOUT.</em>
        </h1>
      </div>
      <section className="panel form auth-form">
        <Link href="/" className="text-link">
          ← RETOUR AU REPAIRE
        </Link>
        <span className="eyebrow">LE CONTRAT SCARLET</span>
        <h2>
          {user
            ? "Tu es connecté"
            : mode === "signup"
              ? "Crée ton compte."
              : "Bon retour."}
        </h2>
        {user ? (
          <Link href="/" className="button">
            CONTINUER <ArrowRight />
          </Link>
        ) : (
          <>
            <div className="tabs">
              <button
                className={mode === "signup" ? "selected" : ""}
                onClick={() => {
                  setMode("signup");
                  setMessage("");
                }}
              >
                Créer un compte
              </button>
              <button
                className={mode === "login" ? "selected" : ""}
                onClick={() => {
                  setMode("login");
                  setMessage("");
                }}
              >
                Connexion
              </button>
            </div>
            {!supabase && (
              <p className="notice">
                Les comptes cloud seront disponibles une fois Supabase
                configuré. Tu peux déjà jouer et sauvegarder sur ce navigateur.
              </p>
            )}
            <form className="form" onSubmit={submit}>
              <label>
                Adresse e-mail
                <input
                  type="email"
                  name="email"
                  autoComplete="email"
                  required
                  maxLength={254}
                />
              </label>
              <label>
                Mot de passe
                <input
                  type="password"
                  name="password"
                  minLength={8}
                  maxLength={128}
                  autoComplete={
                    mode === "signup" ? "new-password" : "current-password"
                  }
                  required
                />
              </label>
              <Button type="submit" disabled={busy || !supabase}>
                {busy
                  ? "CONNEXION…"
                  : mode === "signup"
                    ? "CRÉER MON COMPTE"
                    : "SE CONNECTER"}{" "}
                <ArrowRight size={17} />
              </Button>
            </form>
            <p role="status">{message}</p>
            <small>
              Chaque compte possède sa propre aventure. Ta partie locale reste
              conservée séparément dans ce navigateur.
            </small>
          </>
        )}
      </section>
    </main>
  );
}
