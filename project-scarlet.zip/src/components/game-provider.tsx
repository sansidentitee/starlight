"use client";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  useCallback,
} from "react";
import type { User } from "@supabase/supabase-js";
import { GameState, initialState, isGameState } from "@/lib/game";
import { supabase } from "@/lib/supabase";
type Context = {
  state: GameState;
  update: (fn: (s: GameState) => GameState) => void;
  ready: boolean;
  user: User | null;
  status: string;
  error: string;
  retry: () => void;
  toast: string;
  notify: (text: string) => void;
};
const GameContext = createContext<Context | null>(null);
export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<GameState>(initialState);
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [status, setStatus] = useState("Chargement…");
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [attempt, setAttempt] = useState(0);
  const generation = useRef(0);
  const saved = useRef("");
  const queue = useRef(Promise.resolve());
  const notify = useCallback((text: string) => setToast(text), []);
  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(""), 3500);
      return () => clearTimeout(t);
    }
  }, [toast]);
  useEffect(() => {
    let active = true;
    let lastId: string | undefined;
    const load = async (nextUser: User | null) => {
      if (!active || lastId === (nextUser?.id || "guest")) return;
      lastId = nextUser?.id || "guest";
      const g = ++generation.current;
      setReady(false);
      setError("");
      setUser(nextUser);
      try {
        let next = initialState();
        if (nextUser && supabase) {
          const { data, error } = await supabase
            .from("player_saves")
            .select("data")
            .eq("user_id", nextUser.id)
            .maybeSingle();
          if (error) throw error;
          if (data) {
            if (!isGameState(data.data))
              throw new Error(
                "Sauvegarde incompatible. Aucune donnée n’a été écrasée.",
              );
            next = data.data;
          }
        } else {
          const raw = localStorage.getItem("scarlet:guest:v1");
          if (raw) {
            const parsed = JSON.parse(raw);
            if (!isGameState(parsed))
              throw new Error(
                "Sauvegarde locale incompatible. Exportez les données avant de réinitialiser le stockage.",
              );
            next = parsed;
          }
        }
        if (active && g === generation.current) {
          saved.current = JSON.stringify(next);
          setState(next);
          setStatus(nextUser ? "Synchronisé" : "Sauvegarde locale");
          setReady(true);
        }
      } catch (e) {
        if (active && g === generation.current)
          setError(
            e instanceof Error
              ? e.message
              : "Impossible de charger la sauvegarde. Vérifiez la connexion et les tables Supabase.",
          );
      }
    };
    if (!supabase) {
      void load(null);
      return () => {
        active = false;
        generation.current++;
      };
    }
    void supabase.auth.getSession().then(({ data, error }) => {
      if (error) {
        if (active) setError(error.message);
      } else void load(data.session?.user ?? null);
    });
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setTimeout(() => {
        void load(session?.user ?? null);
      }, 0);
    });
    return () => {
      active = false;
      generation.current++;
      subscription.unsubscribe();
    };
  }, [attempt]);
  useEffect(() => {
    if (!ready) return;
    const serialized = JSON.stringify(state);
    if (serialized === saved.current) return;
    const g = generation.current;
    setStatus(user ? "Sauvegarde…" : "Sauvegarde locale");
    try {
      localStorage.setItem(
        user ? `scarlet:backup:${user.id}` : "scarlet:guest:v1",
        serialized,
      );
    } catch {
      setStatus("Stockage local indisponible");
      notify(
        "Le navigateur ne peut pas sauvegarder cette partie. Exporte ton histoire depuis les paramètres.",
      );
    }
    if (!user || !supabase) {
      saved.current = serialized;
      return;
    }
    const id = user.id;
    queue.current = queue.current
      .then(async () => {
        if (g !== generation.current) return;
        const { error } = await supabase!
          .from("player_saves")
          .upsert({
            user_id: id,
            data: state,
            updated_at: new Date().toISOString(),
          });
        if (g === generation.current) {
          if (error) {
            setStatus("Échec de synchronisation");
            notify(
              "Sauvegarde cloud impossible. Copie locale conservée ; réessaie dans les paramètres.",
            );
          } else {
            saved.current = serialized;
            setStatus("Synchronisé");
          }
        }
      })
      .catch(() => {
        if (g === generation.current) setStatus("Échec de synchronisation");
      });
  }, [state, ready, user, notify]);
  return (
    <GameContext.Provider
      value={{
        state,
        update: (fn) => setState((s) => fn(s)),
        ready,
        user,
        status,
        error,
        retry: () => {
          if (ready) {
            saved.current = "";
            setState((s) => ({ ...s }));
          } else setAttempt((a) => a + 1);
        },
        toast,
        notify,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}
export function useGame() {
  const context = useContext(GameContext);
  if (!context) throw new Error("GameProvider manquant");
  return context;
}
