# Vérifications de cette livraison

- Installation avec fichier de verrouillage : réussie ; audit npm, aucune vulnérabilité signalée au moment de l’installation.
- Tests métier : **6 réussis sur 6**. XP et stat d’une quête, idempotence, identifiant inconnu, étapes de Palais, rangs de Confidants limités par jour, seuils de niveau et validation de sauvegarde.
- Compilation de production `npm run build` : réussie, contrôle TypeScript inclus.
- Serveur de production : démarrage réussi.
- Routes `/`, `/quetes`, `/calendrier`, `/confidants`, `/palais`, `/mementos`, `/stats`, `/journal`, `/compendium`, `/chambre`, `/parametres`, `/profil`, `/connexion`, `/onboarding` : réponses HTTP **200**.
- Route inconnue : réponse **404**.

## Limites des vérifications

L’outil de navigateur de cet environnement a expiré à plusieurs reprises, y compris lors de la sélection d’un onglet. Le rendu visuel, les interactions dans le navigateur, la persistance après rechargement et les dimensions mobiles n’ont donc **pas pu être validés de bout en bout** ici. Les réponses HTTP et la compilation ne remplacent pas ces tests.

Aucun projet Supabase ni environnement Vercel n’était configuré. L’inscription réelle, l’e-mail de confirmation, la connexion, la synchronisation distante et l’isolation RLS entre deux comptes restent à vérifier après configuration. Aucun déploiement n’a été effectué.

Le dépôt GitHub fourni n’a pas été modifié. À la demande de l’utilisateur, la livraison se fait par archive importable.

## Recette conseillée dans Codespaces

1. Lancer `npm ci`, puis `npm run dev`, et ouvrir le port 3000.
2. Parcourir les cinq étapes du tutoriel et créer un nom de code.
3. Terminer une quête : vérifier l’XP, la stat et le bouton désactivé. Recharger et vérifier la conservation.
4. Créer un Palais, avancer une étape ; ajouter une requête Mementos puis la résoudre.
5. Ajouter un Confidant et un moment partagé ; écrire une page de journal.
6. Vérifier le calendrier, le Compendium, la Chambre et l’export JSON.
7. Répéter la navigation à 390 px de largeur et avec la réduction des animations.
8. Après configuration Supabase, tester avec deux comptes distincts et confirmer que leurs aventures restent séparées.
