# Origine des assets

- Ville, immeubles, fenêtres, lune, silhouette au manteau et motifs : SVG originaux écrits pour ce projet dans `src/components/art.tsx`.
- Emblème du site : `src/app/icon.svg`, SVG original.
- Cartes, portraits typographiques, réseau Mementos, radar de stats, textures et découpes : HTML/CSS/SVG originaux.
- Icônes d’interface : Lucide React, licence ISC, distribuées par le paquet npm `lucide-react`.
- Typographie : Barlow et Barlow Condensed de Jeremy Tribby, licence SIL Open Font License 1.1, embarquées par les paquets Fontsource. Voir les fichiers LICENSE de ces paquets.
- Aucun asset, police, image, personnage ou morceau de la franchise Persona n’est distribué. L’image de référence n’est pas intégrée au site ni à l’archive.

La direction artistique évoque les menus de jeu et les codes comic/noir. Aucun service externe d’images, de musique ou de polices n’est requis à l’exécution.
